reearth.ui.show(`
<style>
    html {
  width: 500px;
}

body {
  margin: 0;
  font-size: 12px;
}

*{
  box-sizing: border-box;
}

.extendedh {
  width: 100%;
}

.extendedv {
  height: 100%;
}

#wrapper {
  position: relative;
  background-color: rgba(35, 34, 38, 0.75);
}

#wrapper h1 {
  font-weight: bold;
  color: #fff;
  font-size: 14px;
  margin-bottom: 0.5em;
}

.header{
  font-weight: bold;
  color: #fff;
  font-size: 14px;
  background-color: rgba(0,0,0,.7);
  padding: 4px 10px;
}

.content{
  height: 500px;
  overflow: scroll;
  padding-bottom: 20px;
}

.api-field{
  padding: 2px 10px;
}

.api-item {
  margin: 10px 0;
}

.line{
  width: 100%;
  display: flex;
  justify-content: space-between;
}

.line span {
  flex-shrink: 0;
  display: inline-block;
  width: 150px;
  color: #fff;
  font-weight: bold;
  padding: 0 5px;
}

.btn-ctn{
  width: 100%;
  display: flex;
  flex-wrap: wrap;
}
.btn-ctn button{
  width: 50%;
}

.hidden {
  display: none;
}

.extendedh body,
.extendedh #wrapper {
  width: 100%;
}

.extendedv body,
.extendedv #wrapper {
  height: 100%;
}

::-webkit-scrollbar {
  width: 8px;
  height: 8px;
  background: #000;
}

::-webkit-scrollbar-thumb {
  background: #4a4a4a;
}

::-webkit-scrollbar-corner {
  background: #000;
}

input,
input:focus {
  outline: none;
  border: none;
  background: rgba(0, 0, 0, 0.9);
  color: rgb(180, 180, 180);
  font-size: 12px;
  padding: 0 5px;
  width: 100%;
  height: 21px;
}

input:-internal-autofill-previewed,
input:-internal-autofill-selected {
  background-color: rgba(0, 0, 0, 0) !important;
}

button {
  outline: none;
  border: none;
  background: rgba(0, 0, 0, 0.9);
  color: rgb(180, 180, 180);
  font-size: 12px;
  cursor: pointer;
  width: 100%;
  height: 21px;
  padding: 0 5px;
}

button:hover {
  color: #000;
  background: #ff9900;
}

textarea{
  outline: none;
  border: none;
  background: rgba(0, 0, 0, 0.9);
  color: rgb(180, 180, 180);
  font-size: 12px;
  width: 100%;
  height: 100px;
  padding: 5px;
  resize: none;
  line-height: 1.2;
}

input,
button,
textarea{
  font-family: Menlo, Monaco, 'Courier New', monospace,"Noto Sans","hiragino sans","hiragino kaku gothic proN",-apple-system,BlinkMacSystem,sans-serif;
}

    </style>
    
  <div id="wrapper">
    <div class="header">Plugin API Demo</div>
    <div class="content">

      <div class="api-field">
        <h1>On</h1>
        <div class="api-item">
          <div class="line">
            <span>select</span>
            <input id="selected-id" />
          </div>
        </div>
      </div>

      <div class="api-field">
        <h1>Layers</h1>

        <div class="api-item">
          <div class="line">
            <span>.layers</span>
            <button id="get-layers-layers">Get</button>
          </div>
          <div class="line">
            <span></span>
            <textarea id="get-layers-layers-result" 
            cols="30" rows="10" ></textarea>
          </div>
        </div>
        
        <div class="api-item">
          <div class="line">
            <span>.extensionIds</span>
            <button id="get-layers-extension-ids">Get</button>
          </div>
          <div class="line">
            <span></span>
            <textarea id="get-layers-extension-ids-result" 
            cols="30" rows="10" ></textarea>
          </div>
        </div>

        <div class="api-item">
          <div class="line">
            <span>.append</span>
            <div class="btn-ctn">
              <button id="append-marker-layer">Marker</button>
              <button id="append-photooverlay-layer">PhotoOverlay</button>
              <button id="append-ellipsoid-layer">Ellipsoid</button>
              <button id="append-model-layer">Model</button>
              <button id="append-tileset-layer">Tileset</button>
            </div>
          </div>
        </div>

        <div class="api-item">
          <div class="line">
            <span>.findById</span>
            <input id="layers-find-by-id-id" placeholder="id" />
          </div>
          <div class="line">
            <span></span>
            <button id="layers-find-by-id">Find</button>
          </div>
          <div class="line">
            <span></span>
            <textarea id="layers-find-by-id-result" 
            cols="30" rows="10" ></textarea>
          </div>
        </div>

        <div class="api-item">
          <div class="line">
            <span>.overrideProperty</span>
            <input id="override-target-id" placeholder="id" />
          </div>
          <div class="line">
            <span></span>
            <textarea id="override-properties" 
              placeholder="properties"
              cols="30" rows="10" ></textarea>
          </div>
          <div class="line">
            <span></span>
            <button id="override-property">Override</button>
          </div>
        </div>

      </div>

      <div class="api-field">
        <h1>Visualizer</h1>

        <div class="api-item">
          <div class="line">
            <span>.camera.flyTo</span>
            <button id="camera-flyto-playground">Playground</button>
            <button id="camera-flyto-tileset">Tileset</button>
          </div>
        </div>

      </div>

    </div>

  </div>

    <script>
    console.log('[PLUGIN] inited');

const bindCommonEvent = (event) => {
  document.getElementById(event.eleId).addEventListener("click", (e) => {
    parent.postMessage({
      action: event.action,
    }, "*");
  });
}

// ===================================
// Layers
// ===================================

const commonEvents = [
  // layers
  {
    eleId: "get-layers-layers",
    action: "getLayersLayers",
  },
  {
    eleId: "get-layers-extension-ids",
    action: "getLayersExtensionIds",
  },
  {
    eleId: "append-marker-layer",
    action: "appendMarkerLayer",
  },
  {
    eleId: "append-photooverlay-layer",
    action: "appendPhotooverlayLayer",
  },
  {
    eleId: "append-ellipsoid-layer",
    action: "appendEllipsoidLayer",
  },
  {
    eleId: "append-model-layer",
    action: "appendModelLayer",
  },
  {
    eleId: "append-tileset-layer",
    action: "appendTilesetLayer",
  },
  // helper
  {
    eleId: "camera-flyto-playground",
    action: "cameraFlyToPlayground",
  },
  {
    eleId: "camera-flyto-tileset",
    action: "cameraFlyToTailset",
  },
]

commonEvents.map((event) => {
  bindCommonEvent(event);
})

// ===================================
// Override Property
// ===================================
document.getElementById("override-property").addEventListener("click", (e) => {
  const id = document.getElementById("override-target-id").value;
  if(!id) return;
  const properties = document.getElementById("override-properties").value;
  console.log(id,properties);
  parent.postMessage({
    action: "layersOverrideProperty",
    payload: {
      id,
      properties
    }
  }, "*");
});

// ===================================
// Layers find by id
// ===================================
const layersFindById = (e) => {
  const id = document.getElementById("layers-find-by-id-id").value;
  parent.postMessage({
    action: "layersFindById",
    payload: {
      id,
    }
  }, "*");
};

document.getElementById("layers-find-by-id").addEventListener("click", layersFindById);

// ===================================
// Receive Message
// ===================================
let selectedId = null;

addEventListener("message", e => {
  if (e.source !== parent || !e.data.title) return;
  switch(e.data.title){
    case 'layersLayers':
      document.getElementById("get-layers-layers-result").value = JSON.stringify(e.data.value);
      break;
    case 'layersExtensionIds':
      document.getElementById("get-layers-extension-ids-result").value = JSON.stringify(e.data.value);
      break;
    case 'selectedId':
      document.getElementById("selected-id").value = e.data.value;
      // auto find
      if(selectedId !== e.data.value){
        selectedId = e.data.value;
        document.getElementById("layers-find-by-id-id").value = selectedId;
        layersFindById();
      }
      break;
    case 'layersFindByIdResult':
      document.getElementById("layers-find-by-id-result").value = JSON.stringify(e.data.value);
      // fill override
      if(e.data.value.property){
        document.getElementById("override-properties").value = JSON.stringify(e.data.value.property);
        document.getElementById("override-target-id").value = e.data.value.id;
      }
      break;
    default:
      break;
  }
});
    </script>
`,{width: 500, height: 500});

const randomColor = () => '#'+['00','99','ff'].sort(()=>Math.random()>0.5 ? -1 : 1).join('')+'ff';

const handles = {};

// ===================================
// Layers Properties
// ===================================
handles.getLayersLayers = () => {
  reearth.ui.postMessage({
    title: 'layersLayers',
    value: reearth.layers.layers
  });
}

handles.getLayersExtensionIds = () => {
  reearth.ui.postMessage({
    title: 'layersExtensionIds',
    value: reearth.layers.extensionIds
  });
}

// ===================================
// Append Marker
// ===================================
let markerIndex = 0;
handles.appendMarkerLayer = () => {
  reearth.layers.append({
    extensionId: "marker",
    isVisible: true,
    title: `Marker-${markerIndex}`,
    property: {
      default: {
        location: {
          lat: 49 - 0.5 * markerIndex,
          lng: -102,
        },
        label: true,
        labelText: `Marker from API ${markerIndex.toString()}`,
        labelTypography:{
          fontSize: 18,
          color: randomColor(),
        }
      },
    },
    tags: [],
  });
  markerIndex ++;
}

// ===================================
// Append Photooverlay
// ===================================
const demoPhotoUrls = [
  'https://images.unsplash.com/photo-1655661811387-989070a0fbc3?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1858&q=80',
  'https://images.unsplash.com/photo-1655669131176-c23c3a7b9bfa?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1612&q=80',
  'https://images.unsplash.com/photo-1655434067144-b962fd5fc053?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1548&q=80',
  'https://images.unsplash.com/photo-1652114067562-271dec4fd8f7?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=772&q=80',
  'https://images.unsplash.com/photo-1653245856773-81ec56faf316?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=987&q=80',
];
let photooverlayIndex = 0;
handles.appendPhotooverlayLayer = () => {
  reearth.layers.append({
    extensionId: "photooverlay",
    isVisible: true,
    title: `Photooverlay-${photooverlayIndex}`,
    property: {
      default: {
        location: {
          lat: 49 - 1 * photooverlayIndex,
          lng: -95,
        },
        image: demoPhotoUrls[photooverlayIndex % demoPhotoUrls.length],
        photoOverlayImage: demoPhotoUrls[photooverlayIndex % demoPhotoUrls.length],
      },
    },
    tags: [],
  });
  photooverlayIndex ++;
}

// ===================================
// Append Ellipsoid
// ===================================
let ellipsoidIndex = 0;
handles.appendEllipsoidLayer = () => {
  reearth.layers.append({
    extensionId: "ellipsoid",
    isVisible: true,
    title: `Ellipsolid-${ellipsoidIndex}`,
    property: {
      default: {
        location: {
          lat: 49 - 0.5 * ellipsoidIndex,
          lng: -92,
        },
        radius: 18000 + Math.random() * 5000,
        height: Math.random() * 10000,
        fillColor: randomColor(),
      },
    },
    tags: [],
  });
  ellipsoidIndex ++;
}

// ===================================
// Append Model
// ===================================
const demoModels = [
  {
    url: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/Fox/glTF-Binary/Fox.glb',
    scale: 1000,
  },{
    url: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/master/2.0/CesiumMan/glTF-Binary/CesiumMan.glb',
    scale: 100000,
  }
];
let modelIndex = 0;
handles.appendModelLayer = () => {
  reearth.layers.append({
    extensionId: "model",
    isVisible: true,
    title: `Model-${modelIndex}`,
    property: {
      default: {
        location: {
          lat: 49 - 1 * modelIndex,
          lng: -90,
        },
        model: demoModels[modelIndex % demoModels.length].url,
        scale: demoModels[modelIndex % demoModels.length].scale,
        animation: true,
      },
    },
    tags: [],
  });
  modelIndex ++;
}

// ===================================
// Append Tailset
// ===================================
let tilesetAppended = false;
handles.appendTilesetLayer = () => {
  if(tilesetAppended) return;
  reearth.layers.append({
    extensionId: "tileset",
    isVisible: true,
    title: `Tileset`,
    property: {
      default: {
        tileset: 'https://plateau.reearth.io/13101_chiyoda-ku/tileset.json'
      },
    },
    tags: [],
  });
}

// ===================================
// Override Property
// ===================================
handles.layersOverrideProperty = (payload) => {
  try {
    const properties = eval(`(${payload.properties})`);
    console.log(properties);
    reearth.layers.overrideProperty(payload.id, properties);
  } catch (error) {
    console.log(error);
  }
  
}

// ===================================
// FIndById
// ===================================
handles.layersFindById = (payload) => {
  const layer = reearth.layers.findById(payload.id);
  const layerData = layer ? {
    id: layer.id,
    children: layer.children,
    extensionId: layer.extensionId,
    infobox: layer.infobox,
    isVisible: layer.isVisible,
    pluginId: layer.pluginId,
    property: layer.property,
    propertyId: layer.propertyId,
    tags: layer.tags,
    title: layer.title,
    type: layer.type
  } : {};

  reearth.ui.postMessage({
    title: 'layersFindByIdResult',
    value: layerData
  });
}

// ===================================
// Flyto
// ===================================
handles.cameraFlyToPlayground = () => {
  reearth.visualizer.camera.flyTo({
    lng: -95.3347028122335,
    lat: 42.02136253163602,
    height: 1454623.7781587807,
    heading: 5.329070518200751e-15,
    pitch: -1.1992122922732107,
    roll: 6.2831853071795765,
    fov: 0.75
  });
}
handles.cameraFlyToTailset = () => {
  reearth.visualizer.camera.flyTo({
    lng: 139.74670369973546,
    lat: 35.659869744800325,
    height: 2015.9398450375584,
    heading: 0.09500238074897371,
    pitch: -0.6734953976277236,
    roll: 0.00011756776520588375,
    fov: 0.75
  });
}

// ===================================
// Message
// ===================================
reearth.on("message", msg => {
  if (msg && msg.action) {
    handles[msg.action]?.(msg.payload);
  }
});

// ===================================
// Select
// ===================================
reearth.on("select", msg => {
  console.log(msg);
  reearth.ui.postMessage({
    title: 'selectedId',
    value: msg
  });
})